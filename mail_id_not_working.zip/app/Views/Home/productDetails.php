<?= $this->include('Home/webheader'); ?>

    <main class="ms-main">
        <div class="container">
            <div id="primary" class="content-area single-product">
                <div class="site-main">
                    <div class="woocommerce-notices-wrapper"></div>
                    <div id="product-470" class="ms-single-product product type-product post-470 status-publish first instock product_cat-run product_tag-life product_tag-move product_tag-sport product_tag-trainers has-post-thumbnail shipping-taxable purchasable product-type-simple">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="banner-horizental">
                                    <div class="swiper swiper-container-h1">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <div class="slider-inner">
						<img src="<?php echo base_url(); ?>uploads/Product/<?php  echo $proDetails->pro_img; ?>" alt="No Product Image">

                                                </div>
                                            </div>
									</div>
                                    </div>
                                  
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="ms-single-product__content">
                                    <h2 class="ms-single-product_title"><?php if(!empty($proDetails->pro_name)) echo $proDetails->pro_name; ?></h2><br>
                                    <p class="price">
                                        <span class="woocommerce-Price-amount amount">
                                            <bdi><span class="woocommerce-Price-currencySymbol">Technical Specification</bdi>
                                        </span>
                                    </p>
                                                                        
                                    <div class="product_meta">
                                      <?php if(!empty($proDetails->pro_tech)) echo $proDetails->pro_tech; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 tab-area rts-section-gap">
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Description</button>
                                    </li>
                                </ul>
                                <!-- Tab panes -->
                                <div class="tab-content">
                                    <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab" tabindex="0"> <?php if(!empty($proDetails->pro_desc)) echo $proDetails->pro_desc; ?>
                                    </div>
                                    
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?= $this->include('Home/webfooter'); ?>