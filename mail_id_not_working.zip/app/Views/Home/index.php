<?= $this->include('Home/webheader'); ?>

    <!-- banner area start -->
    <div class="banner-area-start banner-solar-energy-bg bg_image">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12 align-items-center">
                    <div class="banner-solar-energy-inner">
                        <div class="wrapper">
                            <!-- <div class="vedio-icone">
                                <a class="video-play-button play-video" href="#">
                                    <span></span>
                                    <p class="text skew-up">
                                        Introduction Video
                                    </p>
                                </a>
                                <div class="video-overlay">
                                    <a class="video-overlay-close">×</a>
                                </div>
                            </div> -->
                            <h1 class="title skew-up">
                                Vedant Lights: Lighting Your Path to Excellence
                            </h1>
                            <p class="disc skew-up">
                                Vedant Lights: Masterfully tailoring eco-friendly illumination for 5 years.<br>
                                Illuminate spaces with our global quality commitment and cutting-edge technology.<br>
                                Illuminate with absolute confidence—choose Vedant Lights.
                            </p>
                            <div class="button-area ">
                                <a href="aboutus" class="rts-btn btn-primary">More About Us</a>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner area end -->

    <!-- rts service area start -->
    <div class="rts-service-area rts-section-gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-area-center">
                        
                        <h2 class="title skew-up">
                            Why Choose Us ?
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row g-24 mt--30">
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <!-- single service -->
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/trust.png" height="50px" width="50px"  alt="trusted_brands">
                        </div>
                        <h6 class="title">Trusted Brands</h6>
                        <p class="disc">Proud partners of <br>leading brands - Crompton, Philips, Osram, and more. Committed to quality</p>
                        
                    </div>
                    <!-- single service end -->
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <!-- single service -->
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/medal.png" height="50px" width="50px"  alt="leadership">
                        </div>
                        <h6 class="title">Leadership</h6>
                        <p class="disc">Meet our visionaries,<br> Mr. Sudhakar Poul & Mrs. Shital Mastud, setting industry standards.</p>
                        
                    </div>
                    <!-- single service end -->
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <!-- single service -->
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/shield.png" height="50px" width="50px"  alt="Commitment_to_Quality">
                        </div>
                        <h6 class="title">Commitment to Quality</h6>
                        <p class="disc">Certified excellence: Our products meet and exceed industry standards with BIS, ISI, and more.</p>
                        
                    </div>
                    <!-- single service end -->
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <!-- single service -->
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/review.png" height="50px" width="50px"  alt="Client_Satisfaction">
                        </div>
                        <h6 class="title">Client Satisfaction</h6>
                        <p class="disc">Explore our successful projects: Efficient, reliable illumination. Client testimonials attest to our customer satisfaction commitment.</p>
                        
                    </div>
                    <!-- single service end -->
                </div>
                 <!--<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/rocket.png" height="50px" width="50px"  alt="Innovation_and_Sustainability">
                        </div>
                        <h6 class="title">Innovation and Sustainability</h6>
                        <p class="disc">Stay ahead with Vedant Lights, where innovation meets sustainability. Our eco-friendly practices and commitment to energy-efficient solutions contribute to a greener tomorrow.</p>
                        
                    </div>
                    
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/technical-support.png" height="50px" width="50px"  alt="Technical_Expertise">
                        </div>
                        <h6 class="title">Technical Expertise</h6>
                        <p class="disc">Experience unparalleled technical support and customer service. Our team is dedicated to assisting you in making informed decisions and ensuring your lighting needs are met seamlessly.</p>
                        
                    </div>
                    
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/achievement.png" height="50px" width="50px"  alt="Company_Achievements">
                        </div>
                        <h6 class="title">Company Achievements</h6>
                        <p class="disc">We take pride in our achievements, be it industry awards, certifications, or milestones. Vedant Lights continues to set benchmarks in the electrical solutions domain.
                        </p>
                        
                    </div>
                    
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    
                    <div class="rts-single-service-solar-energy">
                        <div class="icon">
                            <img src="web_assets/images/home/communities.png" height="50px" width="50px"  alt="Community_and_Beyond">
                        </div>
                        <h6 class="title">Community and Beyond</h6>
                        <p class="disc">Beyond business, we are committed to social responsibility. Our initiatives extend to community welfare, reflecting our dedication to making a positive impact.</p>
                        
                    </div>
                     
                </div> -->
            </div>
        </div>
    </div>
    <!-- rts service area end -->

    
    <!-- our service area start -->
    <div class="our-service-area-start-solar rts-section-gapTop bg_dark-solar">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-area-center">
                        
                        <h2 class="title skew-up">
                            Our wide Range of Products...
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row mb--60 g-24 mt--20">
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <!-- single serviec area start -->
                    <div class="single-service-start">
                        <div class="image-area">
                            <div href="service-details.html" class="thumbnail">
                                <img src="<?php echo base_url(); ?>web_assets/images/service/Street_Lights.png" alt="service">
                            </div>
                       </div>
                        <div class="inner-content">
                            <div href="service-details.html">
                                <h5 class="title">Street Lights</h5>
                            </div>
                            <p class="disc">
                                • 20-250 Watt<br>
                                • Cool & Warm White<br>
                                • Color Temp: 3000K-5700K<br>
                                </p>
                            <!-- <a href="https://www.vedantlights.com/productDetails/3" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a> -->
                        </div>
                    </div>
                    <!-- single serviec area end -->
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <!-- single serviec area start -->
                    <div class="single-service-start">
                        <div class="image-area">
                            <div href="service-details.html" class="thumbnail">
                                <img src="<?php echo base_url(); ?>web_assets/images/service/Flood_lights.png" alt="service">
                            </div>
                       </div>
                        <div class="inner-content">
                            <div href="service-details.html">
                                <h5 class="title">Flood Lights</h5>
                            </div>
                            <p class="disc">• 20-1000 Watt<br>
• Cool & Warm White<br>
• Color Temp: 3000K-5700K</p>
                            <!-- <a href="service-details.html" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a> -->
                        </div>
                    </div>
                    <!-- single serviec area end -->
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <!-- single serviec area start -->
                    <div class="single-service-start">
                        <div class="image-area">
                            <div href="service-details.html" class="thumbnail">
                                <img src="<?php echo base_url(); ?>web_assets/images/service/Highbay_Lights.png" alt="service">
                            </div>
                       </div>
                        <div class="inner-content">
                            <div href="service-details.html">
                                <h5 class="title">Highbay Lights</h5>
                            </div>
                            <p class="disc">• 80-250 Watt<br>
• Cool & Warm White<br>
• Color Temp: 3000K-5700K</p>
                            <!-- <a href="service-details.html" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a> -->
                        </div>
                    </div>
                    <!-- single serviec area end -->
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <!-- single serviec area start -->
                    <div class="single-service-start">
                        <div class="image-area">
                            <div  class="thumbnail">
                                <img src="<?php echo base_url(); ?>web_assets/images/service/Flalmeproof_Lights.png" alt="service">
                            </div>
                       </div>
                        <div class="inner-content">
                            <div href="service-details.html">
                                <h5 class="title">Flameproof Lights</h5>
                            </div>
                            <p class="disc">• 80-200 Watt<br>
• Cool & Warm White<br>
• Color Temp: 3000K-5700K</p>
                            <!-- <a href="service-details.html" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a> -->
                        </div>
                    </div>
                    <!-- single serviec area end -->
                </div>
            </div>
            <div class="row pt--30 separator-Top rts-section-gapBottom">
                <div class="col-lg-12">
                    <div class="service-solari-short-info">
                        <div class="call">
                            <p>Call us today: <a href="tel:+4733378901">+91 9860638920 / 9890770189</a> <span>or</span></p>
                            <p>Email us: <a href="mailto:
                                sudhakarpoul@vedantlights.com">
                                sudhakarpoul@vedantlights.com</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- our service area end -->

    <div class="rts-cta-area-solar cta-soalr-inner-main rts-section-gap">
        <div class="container-full">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="thumbnail pr--40 pr_sm--0">
                        <img src="<?php echo base_url(); ?>web_assets/images/cta/05.png" alt="cta-imaegs">
                    </div>
                </div>
                <div class="col-lg-6 pl--30 mt_sm--50">
                    <div class="solar-left-inner-area-cta">
                        <div class="title-area-left">
                            <p class="pre">
                                
                            </p>
                            <h2 class="title skew-up">
                                At Vedant Lights India Pvt Ltd,<br>
                                We are proud to uphold our commitment<br> 
                            </h2>
                        </div>
                        <div class="expertiex-solar-inner">
                            <!-- ingle -->
                            <div class="single-exp">
                                <img src="<?php echo base_url(); ?>web_assets/images/cta/06.png" alt="icon">
                                <div class="info-wrapper">
                                    <h5 class="title">Professional Industrial Light Experts</h5>
                                    <p class="dsic">
                                        Vedant Lights: Your Professional Industrial Light Experts. With years of expertise, we specialize in providing cutting-edge lighting solutions 
                                        tailored for industrial environments. Trust us to illuminate your workspace with precision and efficiency
                                    </p>
                                </div>
                            </div>
                            <!-- ingle end -->
                            <!-- ingle -->
                            <div class="single-exp">
                                <img src="<?php echo base_url(); ?>web_assets/images/cta/06.png" alt="icon">
                                <div class="info-wrapper">
                                    <h5 class="title">24/7 Customer Support</h5>
                                    <p class="dsic">
                                        Vedant Lights: Your Illumination Partner with 24/7 Customer Support. We prioritize your needs around the clock, ensuring a seamless experience 
                                        and addressing your inquiries promptly. Count on us for unwavering support in every lighting solution.
                                    </p>
                                </div>
                            </div>
                            <!-- ingle end -->
                        </div>
                        <div class="button-area">
                            <a href="#" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a>
                            <div class="call-btn">
                                <i class="fa-solid fa-phone"></i>
                                <div class="info">
                                    <span>Call Us 24/7</span>
                                    <a href="#" class="title"> +91 9860638920</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="rts-awesome-funfacts-area bg-awesome-feedback">
        <div class="container-75">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="left-awesome-feedback-wrapper">
                        <!-- single feedback area -->
                        <div class="single-awesome-feedback-area large">
                            <div class="wrapper">
                                <h2>2000+</h2>
                                <h5 class="title skew-up">Happy Customers</h5>
                                <p>Customer Satisfaction is our Priority!</p>
                            </div>
                        </div>
                        <!-- single feedback area end -->
                        <!-- single feedback area -->
                        <div class="single-awesome-feedback-area small">
                            <div class="wrapper">
                                <h2>100+</h2>
                                <h5 class="title skew-up">Products Range</h5>
                                <p>Greate product with high quality</p>
                            </div>
                        </div>
                        <!-- single feedback area end -->
                    </div>
                </div>
                <div class="col-lg-6 mt_sm--30">
                    <div class="row align-items-center">
                        <div class="col-lg-12 col-xl-6 padding-feedback-top-btm">
                            <div class="title-area-left">
                                <p class="pre">
                                    <span>Our World</span> Wide Presence
                                </p>
                                <h3 class="title skew-up">
                                    List of Countries We Serve
                                </h3>
                            </div>
                            <div class="awes-me-fun-f-content">
                                <p class="disc skew-up">
                                    Sri Lanka, Qatar, Kuwait, Saudi Arabia, UAE, Oman, Australia, Nepal, Australia, Singapore, Tanzania, Canada, Bangladesh
                                </p>
                                <div class="score-rate">
                                    <span class="score">4.7/5</span>
                                    <div class="info-wrapper">
                                        <p>India Mart Rated</p>
                                        <span>Rated by over 500 customers</span>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-6 pl--control-feedback">
                            <div class="thumbnail">
                                <img src="<?php echo base_url(); ?>web_assets/images/solution/export.png" alt="solution" width = "250px" height="200px">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- rts feedback area start -->
    <div class="rts-feedback-area-solar-energy rts-section-gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-area-center">
                        <p class="pre skew-up">
                            <span> Our</span> Clients Review
                        </p>
                        <h2 class="title skew-up">
                            Customer Feedbacks
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row mt--30 g-24">

                <div class="soalr-feedback-wrapper-main">
                    <div class="swiper swiper-feedback-solar">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <!-- inglle cuystoners fededback -->
                                <div class="rts-single-feedback-solar-energy">
                                    <div class="client-image">
                                        <img src="<?php echo base_url(); ?>web_assets/images/team/21.png" alt="team" width = "100px" height="100px">
                                    </div>
                                    <div class="content">
                                        <p class="para">
                                            Exceptional service and top-notch products! Vedant Lights not only brightened our home but also provided expert guidance. Highly recommended!
                                        </p>
                                        <div class="cottom-review-area">
                                            <div class="stars">
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <p>4.2 Out of 5 Star</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- inglle cuystoners fededback end -->
                            </div>
                            <div class="swiper-slide">
                                <!-- inglle cuystoners fededback -->
                                <div class="rts-single-feedback-solar-energy">
                                    <div class="client-image">
                                        <img src="<?php echo base_url(); ?>web_assets/images/team/21.png" alt="team" width = "90px" height="90px">
                                    </div>
                                    <div class="content">
                                        <p class="para">
                                            Our outdoor space has never looked better! Vedant Lights delivered on their promise of quality and innovation. Delighted with the results!
                                        </p>
                                        <div class="cottom-review-area">
                                            <div class="stars">
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <p>4.9 Out of 5 Star</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- inglle cuystoners fededback end -->
                            </div>
                            <div class="swiper-slide">
                                <!-- inglle cuystoners fededback -->
                                <div class="rts-single-feedback-solar-energy">
                                    <div class="client-image">
                                        <img src="<?php echo base_url(); ?>web_assets/images/team/21.png" alt="team" width = "100px" height="100px">
                                    </div>
                                    <div class="content">
                                        <p class="para">
                                            Vedant Lights truly stands out! Their commitment to excellence is evident in every product. Eco-friendly, efficient, and visually stunning – a perfect combination.
                                        </p>
                                        <div class="cottom-review-area">
                                            <div class="stars">
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <p>4.9 Out of 5 Star</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- inglle cuystoners fededback end -->
                            </div>
                            <div class="swiper-slide">
                                <!-- inglle cuystoners fededback -->
                                <div class="rts-single-feedback-solar-energy">
                                    <div class="client-image">
                                        <img src="<?php echo base_url(); ?>web_assets/images/team/21.png" alt="team" width = "105px" height="105px">
                                    </div>
                                    <div class="content">
                                        <p class="para">
                                            Choosing Vedant Lights was a game-changer for our store. The innovative lighting solutions added a unique touch, attracting more customers. Thank you for the brilliance!
                                        </p>
                                        <div class="cottom-review-area">
                                            <div class="stars">
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                            <p>4.9 Out of 5 Star</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- inglle cuystoners fededback end -->
                            </div>
                        </div>
                        <!-- <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div> -->
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- rts feedback area end -->


    <!-- header style two -->
    <div id="side-bar" class="side-bar header-two">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                <img src="<?php echo base_url(); ?>web_assets/images/banner/04.jpeg" alt="elevate">
            </div>
            <div class="inner-content">
                <h4 class="title"> Empowering global trade
                </h4>
                <p class="disc">
                    Our company seamlessly exports quality products to numerous countries, connecting markets and fostering international growth.
                </p>
                <br>
                <p> Sri Lanka, Qatar, Kuwait,Saudi Arabia, UAE, Oman, Australia, Singapore, Tanzania, Canada, Bangladesh, Nepal </p>
                <div class="footer">
                    <h4 class="title">Got a project in mind?</h4>
                    <a href="contactus.php" class="rts-btn btn-primary">Let's talk</a>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
                <ul class="mainmenu metismenu" id="mobile-menu-active">
                    <li class="has-droupdown">
                        <a href="index.php" class="main">Home</a>
                    </li>
                    <li class="has-droupdown">
                        <a href="aboutus.php" class="main">About Us</a>
                    </li>
                    <li class="has-droupdown">
                        <a href="#" class="main">Brands</a>
                        <ul class="submenu mm-collapse"></ul>
                    </li>
                        <a href="contactus.php" class="main">Contact Us</a>
                    </li>
                </ul>
            </nav>

            <div class="rts-social-style-one pl--20 mt--100">
                <ul>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-youtube"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

<?= $this->include('Home/webfooter'); ?>