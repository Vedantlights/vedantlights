
    <!-- Footer style two -->
    <!-- rts footer area one start -->
    <style>
    .contact-heading {
        text-align: center;
        color : #4aab3d;
        margin-bottom: 5px; /* Adjust margin if necessary */
    }
</style>

    
    <div class="rts-footer-one footer-bg-one ">
        <div class="container">
            <div class="row g-0 bg-cta-footer-one">
                <div class="col-lg-12">
                    <div class="bg-cta-footer-one wrapper">
                        <div class="row align-items-center">
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <a href="https://www.vedantlights.com/" class="logo-area-footer">
            <img src="<?php echo base_url(); ?>web_assets/images/logo/whitelogo.png" alt="logo">
        </a>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <!-- single contact area start -->
        <div class="single-cta-area">
            <!-- <div class="icon">
                <i class="fa-solid fa-phone"></i>
            </div> -->
            <div class="contact-info">
                <div class="contact-heading">Contact no</div>
                <a href="tel:+919860638920">9860638920 / 9890770189</a>
            </div>
        </div>
        <!-- single contact area end -->
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <!-- single contact area start -->
        <div class="single-cta-area">
            <!-- <div class="icon">
                <i class="fa-solid fa-envelope"></i>
            </div> -->
            <div class="contact-info">
                <div class="contact-heading">Email ID</div>
                <a href="mailto:sudhakarpoul@vedantlights.com">sudhakarpoul@vedantlights.com <br> shital@vedantlights.com</a>
            </div>
        </div>
        <!-- single contact area end -->
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <!-- single contact area start -->
        <div class="single-cta-area last">
            <!-- <div class="icon">
                <i class="fa-regular fa-location-dot"></i>
            </div> -->
            <div class="contact-info">
                <div class="contact-heading">Address</div>
                <a href="https://maps.app.goo.gl/c7QFdqq2peZAKRpr5" target="_blank">Office No. 22, 3rd Floor, Aston Plaza, Ambegaon Bk., Pune - 411046.</a>
            </div>
        </div>
        <!-- single contact area end -->
    </div>
</div>

                    </div>
                </div>

            </div>
            <!-- <div class="row pt--90 pb--85 pb_sm--40">
                <div class="col-lg-12">
                    <div class="single-footer-one-wrapper">
                        <div class="single-footer-component first">
                            <div class="title-area">
                                <h5 class="title">About Company</h5>
                            </div>
                            <div class="body">
                                <p class="disc">
                                    At Vedant Lights, we take pride in our unwavering commitment to honest business practices and transparent dealings. Our relentless pursuit of customer satisfaction has propelled us towards unprecedented success, positioning us as one of the leading companies in the LED lighting industry.
                                </p>
                                <div class="rts-social-style-one">
                                    <ul>
                                        <li>
                                            <a href="https://www.facebook.com/vedant.lights">
                                                <i class="fa-brands fa-facebook-f"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://twitter.com/vedant_lights">
                                                <i class="fa-brands fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.youtube.com/@vedantlights">
                                                <i class="fa-brands fa-youtube"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.linkedin.com/company/vedant-lights-india-private-limited?originalSubdomain=in">
                                                <i class="fa-brands fa-linkedin-in"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="single-footer-component">
                            <div class="title-area">
                                <h5 class="title">Useful Links</h5>
                            </div>
                            <div class="body">
                                <div class="pages-footer">
                                    <ul>
                                        <li>
                                            <a href="https://www.vedantlights.com/">
                                                <i class="fa-regular fa-chevron-right"></i>
                                                <p>Home</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.vedantlights.com/aboutus">
                                                <i class="fa-regular fa-chevron-right"></i>
                                                <p>About Us</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.vedantlights.com/brandDetails/1/Crompton">
                                                <i class="fa-regular fa-chevron-right"></i>
                                                <p>Brands</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.vedantlights.com/contactus">
                                                <i class="fa-regular fa-chevron-right"></i>
                                                <p>Contact Us</p>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="single-footer-component">
                            <div class="title-area">
                                <h5 class="title">Brand</h5>
                            </div>
                            <div class="body">
                                <div class="pages-footer">
                                    <ul>
                                        <li>
                                            <a href="https://www.vedantlights.com/brandDetails/2/Bajaj">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <p>Bajaj</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://www.vedantlights.com/brandDetails/1/Crompton">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <p>Crompton</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="service-details.html">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <p>Industry Service</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="service-details.html">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <p>Private Service</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="service-details.html">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <p>Single Service</p>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div> -->
            <div class="row pb--20 pt--20 border-top-copyright">
                <div class="col-lg-12">
                    <!-- copyright area start -->
                    <div class="copyright-area-one text-center">
                        <div class="rts-social-style-one">
                                <ul>
                                    <li>
                                        <a href="https://www.facebook.com/vedantlightsindiaprivatelimited/">
                                            <i class="fa-brands fa-facebook-f"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://x.com/IndiaLight60091">
                                            <i class="fa-brands fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/@vedantlights">
                                            <i class="fa-brands fa-youtube"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.linkedin.com/in/sudhakar-poul/">
                                            <i class="fa-brands fa-linkedin-in"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>                    
                        <div class="left">
                            <p>Copyright 2025. All Rights Reserved.</p>
                        </div>
                        <!-- <div class="right">
                        <ul>
                            <li><a href="#">Terms & conditions</a></li>
                            <li><a href="#">Privacy policy</a></li>
                        </ul>
                    </div> -->
                    </div>
                    <!-- copyright area end -->
                </div>
            </div>
        </div>
        <div class="footer-one-left-right-image">
            <img class="one" src="assets/images/footer/08.png" alt="">
            <img class="two" src="assets/images/footer/09.png" alt="">
        </div>
    </div>

    <!-- Footer style two End -->

    <!-- header style two

    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>  -->


    <!-- pre loader start -->
    <div id="elevate-load">
        <div class="loader-wrapper">
            <div class="lds-ellipsis">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <!-- pre loader end -->


    <div class="search-input-area">
        <div class="container">
            <div class="search-input-inner">
                <div class="input-div">
                    <input id="searchInput1" class="search-input" type="text" placeholder="Search by keyword or #">
                    <button><i class="far fa-search"></i></button>
                </div>
            </div>
        </div>
        <div id="close" class="search-close-icon"><i class="far fa-times"></i></div>
    </div>

    <div id="anywhere-home" class="">
    </div>


    <!-- jquery js -->
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/vendor/jqueryui.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/counter-up.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/swiper.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/metismenu.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/vendor/waypoint.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/vendor/waw.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/gsap.min.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/scrolltigger.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/vendor/split-text.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/vendor/contact.form.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/vendor/split-type.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/jquery-timepicker.js"></script>
    <script src="<?php echo base_url(); ?>web_assets/js/plugins/bootstrap.min.js"></script>

    <script src="<?php echo base_url(); ?>web_assets/js/main.js"></script>
    <!-- header style two End -->
</body>

</html>