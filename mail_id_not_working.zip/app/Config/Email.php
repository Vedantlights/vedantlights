<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Email extends BaseConfig
{
    public $fromEmail  = 'support@vedantlights.com';
    public $fromName   = 'Vedant Lights';

    public $protocol = 'mail'; // important
    public $mailType = 'html';
    public $charset  = 'utf-8';
    public $wordWrap = true;
    public $CRLF    = "\r\n";
    public $newline = "\r\n";
}
