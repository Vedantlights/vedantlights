<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('contactus', 'Home::contactus');
$routes->post('sendmail', 'Home::sendmail');
$routes->get('aboutus', 'Home::aboutus');
$routes->get('brandDetails/(:any)/(:any)', 'Home::brandDetails/$1/$2');
$routes->get('productDetails/(:any)', 'Home::productDetails/$1');
$routes->get('categoryDetails/(:any)/(:any)/(:any)', 'Home::categoryDetails/$1/$2/$3');
$routes->get('categorywiseProductdetails/(:any)/(:any)', 'Home::categorywiseProductdetails/$1/$2');

$routes->get('admin', 'Login::index');
$routes->get('dashboard', 'Login::dashboard');
$routes->post('addBranddetails', 'Brand::addBranddetails');
$routes->get('editBrand/(:any)', 'Brand::editBrand/$1');

$routes->post('updateBranddetails', 'Brand::updateBranddetails');
$routes->post('addCategorydetails', 'Category::addCategorydetails');
$routes->get('editcategory/(:any)', 'Category::editcategory/$1');
$routes->post('updateCategorydetails', 'Category::updateCategorydetails');
$routes->post('addproductdetails', 'Product::addproductdetails');
$routes->get('ProductDetails', 'Product::ProductDetails');
$routes->get('editProductDetails/(:any)', 'Product::editProductDetails/$1');

