<?php

namespace App\Controllers;

use App\Models\HomeModel;

class Home extends BaseController{

	public function __construct(){

		$this->session = \Config\Services::session();

		$this->controller = 'Home';

	$this->HomeModel = new HomeModel();	

	}

 public function index(){

 	$data["brandDetails"] = $this->HomeModel->BrandDetails();

    	echo view($this->controller.'/index',$data);

	 }

 	public function brandDetails($brandId,$brandName){

 	$data["brandName"] = $brandName;

 	$data["brandId"] = $brandId;

 	$data["brandDetails"] = $this->HomeModel->BrandDetails();

 	$data["catDetails"] = $this->HomeModel->getCategoryDetails($brandId);

 	$data["proDetails"] = $this->HomeModel->getCategoryproductDetails($brandId,$data["catDetails"][0]["cat_id"]);

 	echo view($this->controller.'/brandDetails',$data);

	 }

	 public function categoryDetails($brandId,$brandName,$cat_id){

 	$data["brandName"] = $brandName;

 	$data["brandId"] = $brandId;

 	$data["brandDetails"] = $this->HomeModel->BrandDetails();

 	$data["catDetails"] = $this->HomeModel->getCategoryDetails($brandId);

 	$data["proDetails"] = $this->HomeModel->getCategoryproductDetails($brandId,$cat_id);

    	echo view($this->controller.'/brandDetails',$data);

	 }

	  public function productDetails($proid){

	  	$data["brandDetails"] = $this->HomeModel->BrandDetails();

    	 $data["proDetails"] = $this->HomeModel->getproductDetails($proid);

    	echo view($this->controller.'/productDetails',$data);

	 }

	 

	 public function contactus(){

 	$data["brandDetails"] = $this->HomeModel->BrandDetails();

    	echo view($this->controller.'/contactus',$data);

	 }

public function sendmail()
{
    $email = \Config\Services::email();
    $request = service('request');
    $data = $request->getPost();

    // Add validation and safety checks
    $name = $data['name'] ?? '';
    $userEmail = $data['email'] ?? '';
    $subject = $data['subject'] ?? 'No Subject';
    $message = $data['message'] ?? '';

    // Basic validation
    if (empty($name) || empty($userEmail) || empty($message)) {
        log_message('error', 'Contact form: Missing required fields');
        $this->session->setFlashdata('error', 'Please fill all required fields.');
        return redirect()->to(base_url('contactus'));
    }

    $body = "
        <h3>New Contact Form Inquiry</h3>
        <p><b>Name:</b> {$name}</p>
        <p><b>Email:</b> {$userEmail}</p>
        <p><b>Subject:</b> {$subject}</p>
        <p><b>Message:</b><br>{$message}</p>
    ";

    try {
        $email->setTo('sudhakarpoul@vedantlights.com');
        $email->setFrom('sudhakarpoul@vedantlights.com', 'Vedant Lights');
        $email->setSubject('New Website Inquiry: ' . $subject);
        $email->setMessage($body);

        if ($email->send()) {
            log_message('info', 'Contact form email sent successfully to: codenitro.innovations@gmail.com');
            $this->session->setFlashdata('success', 'Mail sent successfully.');
            return redirect()->to(base_url('contactus'));
        } else {
            log_message('error', 'Contact form email failed: ' . $email->printDebugger());
            echo "<h3>Email Debug Information:</h3>";
            echo "<pre>";
            print_r($email->printDebugger());
            echo "</pre>";
            exit;
        }
    } catch (Exception $e) {
        log_message('error', 'Contact form email exception: ' . $e->getMessage());
        echo "<h3>Email Error:</h3>";
        echo "<p>" . $e->getMessage() . "</p>";
        exit;
    }
}
}