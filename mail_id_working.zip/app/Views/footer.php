    <!-- Core -->
    <script src="<?php echo base_url(); ?>admin_asset/bundles/libscripts.bundle.js"></script>
    <script src="<?php echo base_url(); ?>admin_asset/bundles/vendorscripts.bundle.js"></script>
    <script src="<?php echo base_url(); ?>admin_asset/vendor/select2/select2.min.js"></script> 
    <script src="<?php echo base_url(); ?>admin_asset/vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script> 
    <script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-inputmask/jquery.inputmask.bundle.js"></script> 
    <script src="<?php echo base_url(); ?>admin_asset/vendor/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>  
    <script src="<?php echo base_url(); ?>admin_asset/vendor/nouislider/js/nouislider.min.js"></script> 
    <script src="<?php echo base_url(); ?>admin_asset/js/theme.js"></script>
    <script src="<?php echo base_url(); ?>admin_asset/js/pages/advanced-form.js"></script>
    <script src="<?php echo base_url(); ?>admin_asset/bundles/datatablescripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-datatable/buttons/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-datatable/buttons/buttons.colVis.min.js"></script>
<script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-datatable/buttons/buttons.flash.min.js"></script>
<script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-datatable/buttons/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>admin_asset/vendor/jquery-datatable/buttons/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>admin_asset/js/pages/tables/jquery-datatable.js"></script>
      <script src="<?php echo base_url(); ?>admin_asset/js/summernote.js"></script>
  <script>
        $( function() {
  $('.error').fadeOut(10000);
   
  } );
  </script>
  </body>
</html>