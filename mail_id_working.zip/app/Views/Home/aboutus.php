<?= $this->include('Home/webheader'); ?>
    <!-- rts breadcrumb area -->
    <div class="rts-bread-crumb-area bg_image bg-breadcrumb">
        <div class="container ptb--65">
            <div class="row">
                <div class="col-lg-12">
                    <div class="con-tent-main">
                        <div class="wrapper">
                            <span class="bg-text-stok">About Us</span>
                            <div class="title skew-up">
                                <a href="#">About Us</a>
                            </div>
                            <div class="slug skew-up">
                                <a href="#">HOME /</a>
                                <a class="active" href="#index.html">ABOUT US</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- rts breadcrumb area end -->
    <!-- header style two End -->


    <!-- header style two -->
    <div id="side-bar" class="side-bar header-two">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                <img src="<?php echo base_url(); ?>web_assets/images/banner/04.jpeg" alt="elevate">
            </div>
            <div class="inner-content">
                <h4 class="title"> Empowering global trade
                </h4>
                <p class="disc">
                    Our company seamlessly exports quality products to numerous countries, connecting markets and fostering international growth.
                </p>
                <br>
                <p> Sri Lanka, Qatar, Kuwait,Saudi Arabia, UAE, Oman, Australia, Singapore, Tanzania, Canada, Bangladesh, Nepal </p>
                <div class="footer">
                    <h4 class="title">Got a project in mind?</h4>
                    <a href="contact.html" class="rts-btn btn-primary">Let's talk</a>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
                <ul class="mainmenu metismenu" id="mobile-menu-active">
                    <li class="has-droupdown">
                        <a href="index.html" class="main">Home</a>
                    </li>
                    <li class="has-droupdown">
                        <a href="aboutus.html" class="main">About Us</a>
                    </li>
                    <li class="has-droupdown">
                        <a href="brand.html" class="main">Brands</a>
                        <ul class="submenu mm-collapse">
                            <li><a class="mobile-menu-link" href="brand.html">Bajaj</a></li>
                        </ul>
                    </li>
                        <a href="contact.html" class="main">Contact Us</a>
                    </li>
                </ul>
            </nav>

            <div class="rts-social-style-one pl--20 mt--100">
                <ul>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-youtube"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

    <!-- rts about area start -->
    <div class="rts-about-area rts-section-gap">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <!-- about inner solar energy -->
                    <div class="rts-about-left-image-area">
                        <div class="thumbnail">
                            <img src="<?php echo base_url(); ?>web_assets/images/about/nightlight.png" alt="solar energy">
                        </div>
                    </div>
                    <!-- about inner solar energy end -->
                </div>
                <div class="col-lg-6">
                    <!-- about nrighht content area start -->
                    <div class="about-right-content-area-solar-energy">
                        <div class="title-area-left">
                            <p class="pre">
                                <span>Company Overview
                            </p>
                            <h2 class="title skew-up">
                                Illuminate Your Industry with
                                Premium Industrial Lighting Solutions
                            </h2>
                        </div>
                        <!-- nav content start -->
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                <!-- single nav content start -->
                                <div class="single-about-content-solar">
                                    <p class="disc">
                                        Welcome to Vedant Lights India Pvt. Ltd. Founded in 2021
                                        At Vedant Lights India Pvt Ltd, we illuminate the world with a commitment to excellence in providing cutting-edge electrical solutions. With a foundation built on integrity, transparency, and accountability, we embrace a forward-looking approach to cater to diverse industrial lighting needs. <br> <br>
                                        We are proud to uphold our commitment to excellence in providing a diverse range of industrial lighting solutions. Our core values of integrity, transparency, and accountability drive our forward-looking approach. With an innovative team, we set the highest standards of quality, embracing technology to exceed client expectations. Thank you for being part of our story; we look forward to creating a brighter future together
                                    </p>
                                </div>
                                <!-- single nav content end -->
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                <!-- single nav content start -->
                                <div class="single-about-content-solar">
                                    <p class="disc">
                                        Ontes mauris eget aliquet fermentum venenatis taciti tempus dignssim mollis pharetra class habitant congue pulvinar 
                                        rhoncus proin bibendum torquent life ultrices penatibus feugiat phasellus.
                                    </p>
                                    <div class="row align-items-center">
                                        <div class="col-lg-6">
                                            <div class="left-area-wrapper">
                                                <img src="<?php echo base_url(); ?>web_assets/images/about/21.jpg" alt="about">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="<?php echo base_url(); ?>web_assets/images/about/dt.png" alt="dotted">
                                                <p>Experienced Team of Exparts</p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="<?php echo base_url(); ?>web_assets/images/about/dt.png" alt="dotted">
                                                <p>Very first Customers Service</p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="<?php echo base_url(); ?>web_assets/images/about/dt.png" alt="dotted">
                                                <p>Flexiblity Work Environment</p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="<?php echo base_url(); ?>web_assets/images/about/dt.png" alt="dotted">
                                                <p>Provide Quality Service
                                                </p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                        </div>
                                    </div>
                                    <!-- vedio area start -->
                                    <div class="vedio-area-start">
                                        <a href="#" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a>
                                        <div class="vedio-icone">
                                            <a class=" play-video video-play-button" href="#">
                                                <span></span>
                                                <p class="text">
                                                    Play Vedio
                                                </p>
                                            </a>
                                            <div class="video-overlay">
                                                <a class="video-overlay-close">×</a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- vedio area end -->
                                </div>
                                <!-- single nav content end -->
                            </div>
                            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                <!-- single nav content start -->
                                <div class="single-about-content-solar">
                                    <p class="disc">
                                        Ontes mauris eget aliquet fermentum venenatis taciti tempus dignssim mollis pharetra class habitant congue pulvinar rhoncus proin bibendum torquent life ultrices penatibus feugiat phasellus.
                                    </p>
                                    <div class="row align-items-center">
                                        <div class="col-lg-6">
                                            <div class="left-area-wrapper">
                                                <img src="assets/images/about/21.jpg" alt="about">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="assets/images/about/dt.png" alt="dotted">
                                                <p>Experienced Team of Exparts</p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="assets/images/about/dt.png" alt="dotted">
                                                <p>Very first Customers Service</p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="assets/images/about/dt.png" alt="dotted">
                                                <p>Flexiblity Work Environment</p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                            <!-- about ncheck wrapper main -->
                                            <div class="single-ckeck-wrapper">
                                                <img src="assets/images/about/dt.png" alt="dotted">
                                                <p>Provide Quality Service
                                                </p>
                                            </div>
                                            <!-- about ncheck wrapper main end -->
                                        </div>
                                    </div>
                                    <!-- vedio area start -->
                                    <div class="vedio-area-start">
                                        <a href="#" class="rts-btn btn-primary">Read More <i class="fa-regular fa-arrow-right"></i></a>
                                        <div class="vedio-icone">
                                            <a class=" play-video video-play-button" href="#">
                                                <span></span>
                                                <p class="text">
                                                    Play Vedio
                                                </p>
                                            </a>
                                            <div class="video-overlay">
                                                <a class="video-overlay-close">×</a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- vedio area end -->
                                </div>
                                <!-- single nav content end -->
                            </div>
                        </div>
                        <!-- nav content end -->
                        <!-- tab area start about end -->

                    </div>
                    <!-- about nrighht content area end -->
                </div>
            </div>
        </div>
    </div>
    <!-- rts about area end -->

    <!-- rts easy step area start -->
    <div class="rts-easy-step-area rts-section-gapBottom reveal">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-area-center title-g">
                        <p class="pre skew-up">
                            <span>Quality Product</span> Guarantees
                        </p>
                        <h2 class="title skew-up">
                            Why Choose Us
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row mt--10 g-24">
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <!-- single working steps area -->
                    <div class="rts-single-working-process">
                        <div class="icon">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M35 48C27.832 48 22 42.168 22 35C22 27.832 27.832 22 35 22C42.168 22 48 27.832 48 35C48 42.168 42.168 48 35 48ZM35 24C28.934 24 24 28.936 24 35C24 41.064 28.934 46 35 46C41.066 46 46 41.064 46 35C46 28.936 41.066 24 35 24Z" fill="white" />
                                <path d="M33 40C32.736 40 32.48 39.894 32.292 39.708L28.292 35.708C27.902 35.318 27.902 34.684 28.292 34.294C28.682 33.904 29.316 33.904 29.706 34.294L32.95 37.538L39.246 30.342C39.61 29.924 40.242 29.884 40.658 30.248C41.074 30.612 41.116 31.242 40.752 31.658L33.752 39.658C33.57 39.866 33.308 39.99 33.032 40C33.022 40 33.01 40 33 40Z" fill="white" />
                                <path d="M19 42H5C2.244 42 0 39.758 0 37V11C0 8.242 2.244 6 5 6H9C9.552 6 10 6.448 10 7C10 7.552 9.552 8 9 8H5C3.346 8 2 9.346 2 11V37C2 38.654 3.346 40 5 40H19C19.552 40 20 40.448 20 41C20 41.552 19.552 42 19 42Z" fill="white" />
                                <path d="M33 18C32.448 18 32 17.552 32 17V11C32 9.346 30.654 8 29 8H25C24.448 8 24 7.552 24 7C24 6.448 24.448 6 25 6H29C31.756 6 34 8.242 34 11V17C34 17.552 33.552 18 33 18Z" fill="white" />
                                <path d="M23 12H11C9.346 12 8 10.654 8 9V5C8 4.448 8.448 4 9 4H12.1C12.566 1.72 14.584 0 17 0C19.416 0 21.434 1.72 21.9 4H25C25.552 4 26 4.448 26 5V9C26 10.654 24.654 12 23 12ZM10 6V9C10 9.55 10.448 10 11 10H23C23.552 10 24 9.55 24 9V6H21C20.448 6 20 5.552 20 5C20 3.346 18.654 2 17 2C15.346 2 14 3.346 14 5C14 5.552 13.552 6 13 6H10Z" fill="white" />
                                <path d="M27 18H7C6.448 18 6 17.552 6 17C6 16.448 6.448 16 7 16H27C27.552 16 28 16.448 28 17C28 17.552 27.552 18 27 18Z" fill="white" />
                                <path d="M21 24H7C6.448 24 6 23.552 6 23C6 22.448 6.448 22 7 22H21C21.552 22 22 22.448 22 23C22 23.552 21.552 24 21 24Z" fill="white" />
                                <path d="M17 30H7C6.448 30 6 29.552 6 29C6 28.448 6.448 28 7 28H17C17.552 28 18 28.448 18 29C18 29.552 17.552 30 17 30Z" fill="white" />
                            </svg>
                        </div>
                        <div class="content">
                            <h5 class="title">Wide Product Range</h5>
                            <p class="disc">
                                Explore our extensive catalog of industrial products to meet all your wholesale needs.
                            </p>
                            <div class="step_number">
                                <span>01</span>
                            </div>
                        </div>
                    </div>
                    <!-- single working steps area end -->
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt--70">
                    <!-- single working steps area -->
                    <div class="rts-single-working-process">
                        <div class="icon">
                            <svg width="49" height="48" viewBox="0 0 49 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M20.0173 3.20242C10.7393 3.20242 3.21802 10.7237 3.21802 20.0017C3.21802 29.2796 10.7393 36.8009 20.0173 36.8009C29.2952 36.8009 36.8165 29.2796 36.8165 20.0017C36.8064 10.7279 29.291 3.21252 20.0173 3.20242ZM20.0173 4.80235C24.9586 4.80625 29.5891 7.21454 32.4295 11.2581L30.4296 13.258C29.9429 12.9635 29.3857 12.8059 28.8169 12.802C27.0496 12.802 25.617 14.2346 25.617 16.0018C25.6198 16.5713 25.7765 17.1294 26.0706 17.617L20.8324 22.8551C19.8406 22.2504 18.594 22.2504 17.6022 22.8551L13.9639 19.2169C14.258 18.7293 14.4147 18.1712 14.4175 17.6018C14.4197 15.838 12.9918 14.4065 11.2281 14.4043C9.76942 14.4025 8.49498 15.3892 8.1314 16.8018H5.16353C6.67816 9.80742 12.8608 4.81285 20.0173 4.80235ZM30.4168 16.0018C30.4168 16.8855 29.7005 17.6018 28.8169 17.6018C27.9332 17.6018 27.2169 16.8855 27.2169 16.0018C27.2169 15.1182 27.9332 14.4019 28.8169 14.4019C29.7005 14.4019 30.4168 15.1182 30.4168 16.0018ZM20.8172 25.6014C20.8172 26.4851 20.101 27.2013 19.2173 27.2013C18.3336 27.2013 17.6174 26.4851 17.6174 25.6014C17.6174 24.7177 18.3336 24.0015 19.2173 24.0015C20.101 24.0015 20.8172 24.7177 20.8172 25.6014ZM12.8176 17.6018C12.8176 18.4854 12.1013 19.2017 11.2177 19.2017C10.334 19.2017 9.61773 18.4854 9.61773 17.6018C9.61773 16.7181 10.334 16.0018 11.2177 16.0018C12.1013 16.0018 12.8176 16.7181 12.8176 17.6018ZM27.4023 33.2916C25.1432 34.546 22.6013 35.2032 20.0173 35.2009C11.6286 35.2066 4.82365 28.411 4.81795 20.0224C4.81755 19.481 4.84615 18.9399 4.90354 18.4016H8.1314C8.49508 19.8101 9.76302 20.796 11.2177 20.8015C11.7871 20.7987 12.3452 20.642 12.8328 20.3479L16.471 23.9862C16.1769 24.4738 16.0202 25.0318 16.0174 25.6013C16.0174 27.3685 17.4501 28.8012 19.2173 28.8012C20.9845 28.8012 22.4171 27.3685 22.4171 25.6013C22.4143 25.0318 22.2577 24.4738 21.9636 23.9862L27.2017 18.748C27.6893 19.0421 28.2474 19.1988 28.8169 19.2016C30.5841 19.2016 32.0167 17.769 32.0167 16.0017C32.0139 15.4323 31.8572 14.8742 31.5631 14.3866L33.307 12.6435C37.3784 19.976 34.7347 29.2204 27.4023 33.2916Z" fill="#FD8F14" />
                                <path d="M40.0163 8.0022C41.471 7.9967 42.7389 7.01085 43.1026 5.60231H48.016V4.00239H43.1026C42.7389 2.59385 41.471 1.608 40.0163 1.6025C38.2491 1.6025 36.8165 3.03513 36.8165 4.80235C36.8193 5.37182 36.976 5.9299 37.2701 6.41748L35.8645 7.82301C29.1393 -0.938688 16.5847 -2.58961 7.82301 4.13558C-0.938688 10.8608 -2.58961 23.4155 4.13558 32.1772C10.4837 40.4475 22.1203 42.4537 30.8712 36.7865L40.8563 46.7716C42.4941 48.4095 45.1494 48.4095 46.7872 46.7716C48.4251 45.1338 48.4251 42.4785 46.7872 40.8407L36.8021 30.8556C41.0878 24.2543 41.0878 15.7491 36.8021 9.14775L38.402 7.54782C38.8893 7.84201 39.4472 7.999 40.0163 8.0022ZM40.0163 3.20242C40.9 3.20242 41.6163 3.91869 41.6163 4.80235C41.6163 5.68601 40.9 6.40228 40.0163 6.40228C39.1327 6.40228 38.4164 5.68601 38.4164 4.80235C38.4164 3.91869 39.1328 3.20242 40.0163 3.20242ZM45.6561 41.9719C46.6806 42.9734 46.6993 44.6159 45.6978 45.6405C44.6962 46.665 43.0537 46.6837 42.0291 45.6822C42.015 45.6685 42.0013 45.6546 41.9874 45.6405L35.5477 39.2008L39.2164 35.5321L45.6561 41.9719ZM38.0852 34.401L34.4166 38.0696L32.2023 35.8553C32.3151 35.7689 32.4207 35.6737 32.5319 35.5849C32.6431 35.4961 32.7719 35.3898 32.8911 35.2898C33.0663 35.1426 33.239 34.9938 33.4086 34.841C33.4958 34.761 33.579 34.681 33.6646 34.601C33.9926 34.2938 34.3102 33.9762 34.6174 33.6482C34.6974 33.5626 34.7774 33.4794 34.8574 33.3922C35.0102 33.2227 35.159 33.0499 35.3062 32.8747C35.4065 32.7563 35.5048 32.6366 35.6013 32.5155C35.6893 32.4051 35.7845 32.2995 35.8709 32.1867L38.0852 34.401ZM34.983 30.6852C34.731 31.0372 34.471 31.3819 34.1966 31.7139C34.1166 31.8107 34.031 31.9043 33.9486 31.9995C33.7038 32.2843 33.451 32.5606 33.1903 32.8283C33.0767 32.9456 32.9612 33.0611 32.8439 33.1747C32.5772 33.4354 32.301 33.6882 32.0151 33.933C31.9199 34.013 31.8263 34.1002 31.7295 34.181C31.3975 34.4554 31.0527 34.7154 30.7008 34.9674C22.4195 40.8836 10.9102 38.9664 4.99394 30.6852C-0.922288 22.4039 0.994924 10.8946 9.27614 4.97834C17.5574 -0.937888 29.0667 0.979225 34.983 9.26055C39.5609 15.6685 39.5609 24.2773 34.983 30.6852Z" fill="#FD8F14" />
                            </svg>
                        </div>
                        <div class="content">
                            <h5 class="title">Competitive Pricing</h5>
                            <p class="disc">
                                Benefit from competitive prices, ensuring cost-effectiveness for your business.
                            </p>
                            <div class="step_number">
                                <span>02</span>
                            </div>
                        </div>
                    </div>
                    <!-- single working steps area end -->
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                    <!-- single working steps area -->
                    <div class="rts-single-working-process">
                        <div class="icon">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M29.8216 35.3009C31.2248 35.3009 32.6281 34.7668 33.6964 33.6985C35.8329 31.562 35.8329 28.0856 33.6964 25.9491C31.5598 23.8125 28.0835 23.8125 25.9469 25.9491C23.8104 28.0856 23.8104 31.562 25.9469 33.6985C27.0151 34.7667 28.4184 35.3009 29.8216 35.3009ZM26.9408 26.943C27.7351 26.1486 28.7782 25.7516 29.8216 25.7516C30.8648 25.7516 31.9083 26.1488 32.7024 26.943C34.2909 28.5315 34.2909 31.1161 32.7024 32.7045C31.114 34.2931 28.5292 34.293 26.9408 32.7045C25.3522 31.1161 25.3522 28.5315 26.9408 26.943Z" fill="#FD8F14" />
                                <path d="M23.4428 23.445C20.8281 26.0599 20.0721 29.9487 21.5169 33.3521C21.6686 33.7094 22.0814 33.876 22.4384 33.7244C22.7957 33.5727 22.9624 33.1602 22.8107 32.8029C21.591 29.9295 22.2293 26.6465 24.4368 24.439C27.4061 21.4697 32.2375 21.4698 35.2066 24.439C38.1758 27.4082 38.1758 32.2395 35.2066 35.2087C33.7801 36.6351 31.8838 37.4272 29.8668 37.4391C29.8514 37.4392 29.8363 37.4392 29.8209 37.4392C27.8227 37.4392 25.9366 36.6722 24.5059 35.2769C24.2279 35.0058 23.783 35.0114 23.5121 35.2892C23.2411 35.5671 23.2467 36.0121 23.5246 36.2831C25.2195 37.9363 27.4536 38.8448 29.8207 38.8447C29.8387 38.8447 29.8569 38.8447 29.875 38.8445C32.2643 38.8305 34.5108 37.8922 36.2006 36.2025C39.7177 32.6852 39.7177 26.9623 36.2006 23.4449C32.683 19.9278 26.9602 19.9278 23.4428 23.445Z" fill="#FD8F14" />
                                <path d="M46.6516 26.6684H44.1509C43.7795 24.9738 43.1188 23.3773 42.1865 21.9213L43.9532 20.1545C44.2075 19.9002 44.3475 19.5622 44.3475 19.2027C44.3475 18.8432 44.2076 18.5052 43.9533 18.251L41.3942 15.692C41.14 15.4378 40.8021 15.2977 40.4426 15.2977C40.083 15.2977 39.7451 15.4377 39.4908 15.6919L37.724 17.4588C36.2681 16.5265 34.6716 15.8658 32.9769 15.4944V12.9937C32.9769 12.2516 32.3732 11.6478 31.631 11.6478H28.012C27.5939 11.6478 27.2198 11.8395 26.9728 12.1396H26.5135C26.2141 10.8293 25.702 9.59179 24.9896 8.45674L26.3413 7.10503C26.8179 6.62835 26.8179 5.85285 26.3413 5.37607L24.273 3.30781C24.042 3.07692 23.735 2.94976 23.4085 2.94976C23.0819 2.94976 22.7748 3.07692 22.544 3.3079L21.1923 4.65951C20.0575 3.94716 18.8199 3.43506 17.5094 3.13557V1.22258C17.5095 0.548459 16.9612 0 16.287 0H13.362C12.6879 0 12.1395 0.548459 12.1395 1.22258V3.13567C10.8291 3.43515 9.59142 3.94735 8.45664 4.6596L7.10513 3.30799C6.87424 3.07701 6.56726 2.94985 6.2406 2.94985C5.91394 2.94985 5.60687 3.07701 5.37598 3.30799L3.3079 5.37617C2.83131 5.85285 2.83131 6.62835 3.3079 7.10513L4.6596 8.45683C3.94725 9.59161 3.43515 10.8293 3.13567 12.1396H1.22258C0.548458 12.1396 0 12.6881 0 13.3622V16.2871C0 16.9613 0.548458 17.5097 1.22258 17.5097H3.13567C3.43515 18.8202 3.94725 20.0579 4.6596 21.1925L3.3079 22.5442C2.83122 23.0209 2.83122 23.7965 3.3079 24.2732L5.37607 26.3415C5.85275 26.8181 6.62826 26.8182 7.10513 26.3415L8.45683 24.9898C9.59151 25.7021 10.829 26.2142 12.1396 26.5137V26.9736C11.8383 27.2206 11.6456 27.5953 11.6456 28.0145V31.6336C11.6456 32.3757 12.2494 32.9795 12.9915 32.9795H15.4922C15.8637 34.6741 16.5244 36.2708 17.4566 37.7266L15.6899 39.4934C15.4355 39.7476 15.2956 40.0856 15.2956 40.4452C15.2956 40.8047 15.4356 41.1427 15.6898 41.3969L18.2489 43.9559C18.5031 44.2101 18.841 44.3502 19.2005 44.3502C19.5601 44.3502 19.898 44.2102 20.1523 43.956L21.919 42.189C23.375 43.1214 24.9717 43.7821 26.6662 44.1534V46.6541C26.6662 47.3963 27.2699 48 28.012 48H31.631C32.3732 48 32.9769 47.3963 32.9769 46.6541V44.1531C34.6716 43.7818 36.2682 43.121 37.7241 42.1888L39.4909 43.9557C39.7451 44.2098 40.083 44.3499 40.4426 44.3499C40.8021 44.3499 41.14 44.2099 41.3942 43.9557L43.9532 41.3967C44.2075 41.1424 44.3475 40.8045 44.3475 40.4449C44.3475 40.0854 44.2076 39.7474 43.9533 39.4932L42.1865 37.7263C43.1187 36.2706 43.7794 34.6739 44.1509 32.9792H46.6516C47.3937 32.9792 47.9975 32.3755 47.9975 31.6333V28.0142C47.9976 27.2722 47.3937 26.6684 46.6516 26.6684ZM12.578 25.1711C11.3331 24.9022 10.1615 24.4174 9.09553 23.7301C8.6136 23.4196 7.97097 23.4875 7.567 23.8915L6.2406 25.218L4.43115 23.4086L5.75764 22.082C6.16161 21.6779 6.22945 21.0352 5.919 20.5535C5.23167 19.4876 4.74684 18.3159 4.47791 17.0709C4.35674 16.5106 3.8542 16.104 3.28288 16.104H1.40558V13.5451H3.28297C3.8542 13.5451 4.35684 13.1385 4.47809 12.5779C4.74693 11.3331 5.23177 10.1615 5.9191 9.09553C6.22954 8.61398 6.1617 7.97115 5.75774 7.5671L4.43124 6.2406L6.24069 4.43115L7.5671 5.75764C7.97106 6.1617 8.6136 6.22954 9.09571 5.919C10.1617 5.23167 11.3333 4.74684 12.578 4.478C13.1384 4.35693 13.5451 3.8543 13.5451 3.28288V1.40558H16.104V3.28297C16.104 3.85439 16.5108 4.35703 17.0712 4.47809C18.3159 4.74694 19.4875 5.23177 20.5536 5.919C21.0352 6.22945 21.678 6.1618 22.0822 5.75764L23.4086 4.43115L25.218 6.2406L23.8916 7.567C23.4875 7.97106 23.4196 8.61388 23.7302 9.09553C24.4176 10.1617 24.9024 11.3334 25.1712 12.5779C25.2922 13.1384 25.7948 13.5451 26.3663 13.5451H26.6663V15.4944C24.9717 15.8658 23.3751 16.5265 21.9192 17.4588L20.1523 15.6919C20.1313 15.6709 20.109 15.652 20.0869 15.6326C20.3334 14.0137 19.8354 12.3022 18.5913 11.0581C17.1194 9.58617 14.908 9.10602 12.9575 9.83468C12.5939 9.97055 12.4092 10.3755 12.5452 10.739C12.681 11.1026 13.0859 11.2872 13.4495 11.1514C14.8854 10.6148 16.5137 10.9682 17.5974 12.0519C18.5068 12.9613 18.8732 14.2097 18.7007 15.394C18.5336 15.4609 18.3801 15.5609 18.249 15.6919L15.69 18.2509C15.5586 18.3822 15.4584 18.5362 15.3916 18.7035C15.2054 18.7306 15.0163 18.7458 14.8247 18.7458C13.7772 18.7458 12.7926 18.3379 12.052 17.5973C10.8144 16.3597 10.5476 14.4308 11.4032 12.9067C11.5932 12.5683 11.4728 12.1398 11.1344 11.9499C10.7961 11.76 10.3676 11.8803 10.1775 12.2187C9.01494 14.2898 9.37702 16.9103 11.058 18.5913C12.0964 19.6297 13.4606 20.1489 14.8246 20.1489C15.0935 20.1489 15.3622 20.1277 15.6286 20.0871C15.6485 20.1099 15.6681 20.1329 15.6898 20.1545L17.4566 21.9214C16.5244 23.3772 15.8636 24.9739 15.4922 26.6685H13.5451V26.3663C13.5451 25.7949 13.1385 25.2922 12.578 25.1711ZM46.592 31.5736H44.1023C43.4733 31.5736 42.92 32.0215 42.7866 32.6388C42.4496 34.1986 41.8421 35.6669 40.9809 37.0026C40.6389 37.533 40.7135 38.2409 41.1582 38.6856L42.9173 40.4448L40.4426 42.9195L38.6835 41.1602C38.2389 40.7155 37.531 40.6408 37.0007 40.9828C35.6647 41.8441 34.1964 42.4516 32.6366 42.7886C32.0195 42.9219 31.5715 43.4752 31.5715 44.1043V46.594H28.0718V44.1043C28.0718 43.4753 27.6239 42.922 27.0067 42.7886C25.447 42.4517 23.9788 41.8441 22.6427 40.9828C22.1125 40.6409 21.4047 40.7154 20.9598 41.1602L19.2007 42.9194L16.7261 40.4447L18.4851 38.6855C18.93 38.2407 19.0046 37.5329 18.6626 37.0025C17.8013 35.6667 17.1937 34.1985 16.8568 32.6386C16.7233 32.0214 16.1701 31.5734 15.5411 31.5734H13.0514V28.0737H15.5411C16.1701 28.0737 16.7233 27.6258 16.8568 27.0086C17.1937 25.4487 17.8012 23.9805 18.6625 22.6447C19.0046 22.1142 18.93 21.4065 18.4852 20.9617L16.7261 19.2025L19.2007 16.7278L20.9598 18.4871C21.4045 18.9318 22.1123 19.0064 22.6427 18.6645C23.9788 17.8032 25.447 17.1956 27.0067 16.8587C27.6239 16.7254 28.0718 16.1721 28.0718 15.543V13.0533H31.5715V15.5429C31.5715 16.172 32.0195 16.7253 32.6366 16.8587C34.1964 17.1955 35.6646 17.8031 37.0007 18.6645C37.5309 19.0063 38.2387 18.9319 38.6836 18.487L40.4426 16.7278L42.9173 19.2024L41.1582 20.9619C40.7133 21.4067 40.6387 22.1145 40.9807 22.6448C41.8419 23.9807 42.4495 25.4489 42.7865 27.0088C42.9199 27.626 43.4732 28.074 44.1022 28.074H46.5919V31.5736H46.592Z" fill="#FD8F14" />
                            </svg>
                        </div>
                        <div class="content">
                            <h5 class="title">Fast Shipping</h5>
                            <p class="disc">
                                Enjoy timely deliveries to keep your operations running smoothly.
                            </p>
                            <div class="step_number">
                                <span>03</span>
                            </div>
                        </div>
                    </div>
                    <!-- single working steps area end -->
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt--70">
                    <!-- single working steps area -->
                    <div class="rts-single-working-process">
                        <div class="icon">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M25.5002 36.75V39.75C25.5002 40.164 25.8355 40.5 26.2502 40.5H35.2501C35.6649 40.5 36.0001 40.164 36.0001 39.75V36.75C36.0001 36.336 35.6649 36 35.2501 36H26.2502C25.8355 36 25.5002 36.336 25.5002 36.75ZM27.0002 37.5H34.5001V39H27.0002V37.5Z" fill="#FD8F14" />
                                <path d="M41.8358 21.2812C41.8268 21.27 41.8141 21.2655 41.8043 21.255C41.7691 21.2153 41.7263 21.1852 41.6836 21.1537C41.6468 21.1275 41.6131 21.099 41.5733 21.0795C41.5313 21.0592 41.4863 21.0502 41.4406 21.0375C41.3903 21.024 41.3423 21.0105 41.2906 21.0075C41.2763 21.0075 41.2643 21 41.2501 21H6.75038C6.73613 21 6.72338 21.0075 6.70913 21.0082C6.65813 21.0112 6.61088 21.0247 6.56138 21.0382C6.51488 21.051 6.46914 21.06 6.42639 21.0802C6.38739 21.099 6.35439 21.1275 6.31764 21.153C6.27414 21.1845 6.23139 21.2145 6.19539 21.255C6.18564 21.2655 6.17289 21.27 6.16389 21.2812L0.163944 28.7812C-0.0160544 29.0063 -0.0505541 29.3145 0.0739447 29.5747C0.199944 29.835 0.461691 30 0.750438 30H6.00039V46.5C6.00039 47.3273 6.67313 48 7.50038 48H40.5001C41.3273 48 42.0001 47.3273 42.0001 46.5V30H47.25C47.5388 30 47.8005 29.835 47.9258 29.5747C48.0503 29.3152 48.0157 29.0063 47.8358 28.7812L41.8358 21.2812ZM7.11113 22.5H18.6895L13.8896 28.5H2.31117L7.11113 22.5ZM7.50038 30H14.2503C14.4783 30 14.6936 29.8965 14.8361 29.7188L19.5003 23.8883V46.5H7.50038V30ZM40.5001 46.5H21.0002V23.8883L25.6645 29.718C25.807 29.8965 26.0222 30 26.2502 30H40.5001V46.5ZM26.6102 28.5L21.8102 22.5H40.8886L45.6885 28.5H26.6102Z" fill="#FD8F14" />
                                <path d="M19.6285 12.6705L18.853 17.1908C18.805 17.472 18.9205 17.7563 19.1508 17.9243C19.3833 18.0923 19.6885 18.114 19.9413 17.9813L24.0002 15.8475L28.0592 17.982C28.1687 18.0398 28.2894 18.0682 28.4087 18.0682C28.5639 18.0682 28.7192 18.0203 28.8497 17.925C29.0807 17.757 29.1962 17.4728 29.1474 17.1915L28.3719 12.6713L31.6569 9.47025C31.8609 9.27075 31.9344 8.973 31.8467 8.7015C31.7582 8.43 31.5234 8.232 31.2407 8.19075L26.7017 7.5315L24.6722 3.41925C24.4202 2.907 23.5795 2.907 23.3275 3.41925L21.298 7.5315L16.759 8.19075C16.4763 8.232 16.2423 8.43 16.153 8.7015C16.0653 8.973 16.138 9.27075 16.3428 9.47025L19.6285 12.6705ZM21.904 8.95875C22.1485 8.9235 22.3592 8.76975 22.4687 8.5485L24.0002 5.445L25.5317 8.5485C25.6405 8.76975 25.852 8.9235 26.0964 8.95875L29.5209 9.456L27.0422 11.8717C26.8659 12.0443 26.7849 12.2925 26.8269 12.5355L27.4119 15.9465L24.349 14.3363C24.2395 14.2785 24.1202 14.25 24.0002 14.25C23.8802 14.25 23.761 14.2785 23.6507 14.3363L20.5878 15.9465L21.1727 12.5355C21.2147 12.2925 21.1337 12.0443 20.9575 11.8717L18.4788 9.456L21.904 8.95875Z" fill="#FD8F14" />
                                <path d="M6.18189 10.5225C5.78289 10.4242 5.37864 10.6643 5.2759 11.0648C5.17315 11.4645 5.41539 11.8725 5.81439 11.9767C5.92239 12.0052 8.47687 12.7102 9.8036 16.029C9.92135 16.3215 10.2034 16.5 10.5003 16.5C10.5933 16.5 10.6878 16.4827 10.7786 16.446C11.1633 16.2915 11.3508 15.8558 11.1971 15.471C9.57336 11.412 6.31989 10.557 6.18189 10.5225Z" fill="#FD8F14" />
                                <path d="M1.87543 12C2.90967 12 3.75041 11.1585 3.75041 10.125C3.75041 9.0915 2.90967 8.25 1.87543 8.25C0.841188 8.25 0.000445417 9.0915 0.000445417 10.125C0.000445417 11.1585 0.841188 12 1.87543 12ZM1.87543 9.75C2.08168 9.75 2.25042 9.918 2.25042 10.125C2.25042 10.332 2.08168 10.5 1.87543 10.5C1.66918 10.5 1.50043 10.332 1.50043 10.125C1.50043 9.918 1.66918 9.75 1.87543 9.75Z" fill="#FD8F14" />
                                <path d="M7.12538 3.75C8.15962 3.75 9.00036 2.9085 9.00036 1.875C9.00036 0.8415 8.15962 0 7.12538 0C6.09114 0 5.2504 0.8415 5.2504 1.875C5.2504 2.9085 6.09114 3.75 7.12538 3.75ZM7.12538 1.5C7.33163 1.5 7.50038 1.668 7.50038 1.875C7.50038 2.082 7.33163 2.25 7.12538 2.25C6.91913 2.25 6.75038 2.082 6.75038 1.875C6.75038 1.668 6.91913 1.5 7.12538 1.5Z" fill="#FD8F14" />
                                <path d="M8.47012 4.71975C8.17687 5.013 8.17687 5.487 8.47012 5.78025C9.8216 7.13175 10.5318 9.2175 10.5393 9.23775C10.6443 9.55125 10.9368 9.75 11.2503 9.75C11.3291 9.75 11.4093 9.73725 11.4881 9.711C11.8803 9.57975 12.0926 9.156 11.9613 8.763C11.9291 8.66475 11.1371 6.32625 9.53061 4.71975C9.23736 4.4265 8.76336 4.4265 8.47012 4.71975Z" fill="#FD8F14" />
                                <path d="M41.8186 10.5225C41.6806 10.557 38.4278 11.4127 36.8034 15.4718C36.6496 15.8565 36.8371 16.293 37.2219 16.4468C37.3126 16.4827 37.4071 16.5 37.5001 16.5C37.7971 16.5 38.0791 16.3215 38.1968 16.0282C39.5243 12.7095 42.0788 12.0045 42.1861 11.976C42.5851 11.874 42.8273 11.4683 42.7276 11.0677C42.6271 10.6665 42.2183 10.4198 41.8186 10.5225Z" fill="#FD8F14" />
                                <path d="M46.125 12C47.1593 12 48 11.1585 48 10.125C48 9.0915 47.1593 8.25 46.125 8.25C45.0908 8.25 44.25 9.0915 44.25 10.125C44.25 11.1585 45.0908 12 46.125 12ZM46.125 9.75C46.3313 9.75 46.5 9.918 46.5 10.125C46.5 10.332 46.3313 10.5 46.125 10.5C45.9188 10.5 45.75 10.332 45.75 10.125C45.75 9.918 45.9188 9.75 46.125 9.75Z" fill="#FD8F14" />
                                <path d="M40.8751 3.75C41.9093 3.75 42.75 2.9085 42.75 1.875C42.75 0.8415 41.9093 0 40.8751 0C39.8408 0 39.0001 0.8415 39.0001 1.875C39.0001 2.9085 39.8408 3.75 40.8751 3.75ZM40.8751 1.5C41.0813 1.5 41.2501 1.668 41.2501 1.875C41.2501 2.082 41.0813 2.25 40.8751 2.25C40.6688 2.25 40.5001 2.082 40.5001 1.875C40.5001 1.668 40.6688 1.5 40.8751 1.5Z" fill="#FD8F14" />
                                <path d="M36.5131 9.71175C36.5919 9.738 36.6721 9.75 36.7501 9.75C37.0644 9.75 37.3568 9.55125 37.4611 9.237C37.4686 9.216 38.1706 7.13925 39.5303 5.78025C39.8236 5.487 39.8236 5.013 39.5303 4.71975C39.2371 4.4265 38.7631 4.4265 38.4698 4.71975C36.8626 6.32625 36.0714 8.664 36.0391 8.763C35.9079 9.156 36.1201 9.5805 36.5131 9.71175Z" fill="#FD8F14" />
                            </svg>
                        </div>
                        <div class="content">
                            <h5 class="title">Customer Support</h5>
                            <p class="disc">
                                Our team is ready to assist you with any inquiries or assistance required.
                            </p>
                            <div class="step_number">
                                <span>04</span>
                            </div>
                        </div>
                    </div>
                    <!-- single working steps area end -->
                </div>
            </div>
        </div>
    </div>
    <!-- rts easy step area end -->

    

    <!-- our clients feedback start -->
    <div class="rts-clients-feedback rts-section-gapBottom bg-feedback-about bg_image">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="rts-solution-left-area-left">
                        <div class="thumbnail">
                            <img src="<?php echo base_url(); ?>web_assets/images/solution/01.png" alt="solution">
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-6 pl--90 pl_md--10 pl_sm--10 mt_md--50 mt_sm--30">

                    <div class="feed-back-about-wrapper reveal">
                        <div class="title-area-left title-g">
                            <p class="pre ">
                                <span>Only Quality</span> Solution
                            </p>
                            <h2 class="title skew-up">
                                Amazing Feedback Say
                                About Products
                            </h2>
                        </div>
                        <div class="swiper mySwiper-about-feedback">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">

                                    <div class="feedback-about-swiper-wrapper">
                                        <div class="single-feedback-about">
                                            <div class="head">
                                                
                                                <div class="info">
                                                    <h5 class="title">Vinod Shinde</h5>
                                                    <span>Director, GD Lights</span>
                                                </div>
                                            </div>
                                            <div class="body">
                                                <p>“Vedant Lights truly stands out! Their commitment to excellence is evident in every product. Eco-friendly, efficient, and visually stunning – a perfect combination.”</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">

                                    <div class="feedback-about-swiper-wrapper">
                                        <div class="single-feedback-about">
                                            <div class="head">
                                                
                                                <div class="info">
                                                    <h5 class="title">Rahul Jadhav</h5>
                                                    <span>Director, Solotronics</span>
                                                </div>
                                            </div>
                                            <div class="body">
                                                <p>“Vedant Lights transformed our office space! The quality of their lighting solutions exceeded our expectations. Eco-friendly and efficient – exactly what we needed!”</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">

                                    <div class="feedback-about-swiper-wrapper">
                                        <div class="single-feedback-about">
                                            <div class="head">
                                                
                                                <div class="info">
                                                    <h5 class="title">Vijay Jain</h5>
                                                    <span>Director, Volta </span>
                                                </div>
                                            </div>
                                            <div class="body">
                                                <p>“Exceptional service and top-notch products! Vedant Lights not only brightened our home but also provided expert guidance. Highly recommended!”</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div> -->
                            <div class="swiper-pagination"></div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- our clients feedback end -->

<?= $this->include('Home/webfooter'); ?>