<?= $this->include('Home/webheader'); ?>

       <div id="side-bar" class="side-bar header-two">

        <button class="close-icon-menu"><i class="far fa-times"></i></button>

        <!-- inner menu area desktop start -->

        <div class="inner-main-wrapper-desk">

            <div class="thumbnail">

                <img src="<?php echo base_url(); ?>web_assets/images/banner/04.jpeg" alt="elevate">

            </div>

            <div class="inner-content">

                <h4 class="title"> Empowering global trade

                </h4>

                <p class="disc">

                    Our company seamlessly exports quality products to numerous countries, connecting markets and fostering international growth.

                </p>

                <br>

                <p> Sri Lanka, Qatar, Kuwait,Saudi Arabia, UAE, Oman, Australia, Singapore, Tanzania, Canada, Bangladesh, Nepal </p>

                <div class="footer">

                    <h4 class="title">Got a project in mind?</h4>

                    <a href="contact.html" class="rts-btn btn-primary">Let's talk</a>

                </div>

            </div>

        </div>

        <!-- mobile menu area start -->

        <div class="mobile-menu-main">

            <nav class="nav-main mainmenu-nav mt--30">

                <ul class="mainmenu metismenu" id="mobile-menu-active">

                    <li class="has-droupdown">

                        <a href="index.html" class="main">Home</a>

                    </li>

                    <li class="has-droupdown">

                        <a href="aboutus.html" class="main">About Us</a>

                    </li>

                    <li class="has-droupdown">

                        <a href="brand.html" class="main">Brands</a>

                        <ul class="submenu mm-collapse">

                            <li><a class="mobile-menu-link" href="brand.html">Bajaj</a></li>

                        </ul>

                    </li>

                        <a href="contact.html" class="main">Contact Us</a>

                    </li>

                </ul>

            </nav>



            <div class="rts-social-style-one pl--20 mt--100">

                <ul>

                    <li>

                        <a href="#">

                            <i class="fa-brands fa-facebook-f"></i>

                        </a>

                    </li>

                    <li>

                        <a href="#">

                            <i class="fa-brands fa-twitter"></i>

                        </a>

                    </li>

                    <li>

                        <a href="#">

                            <i class="fa-brands fa-youtube"></i>

                        </a>

                    </li>

                    <li>

                        <a href="#">

                            <i class="fa-brands fa-linkedin-in"></i>

                        </a>

                    </li>

                </ul>

            </div>

        </div>

        <!-- mobile menu area end -->

    </div>

    <!-- header style two End -->





    <!-- header style two -->

    <!-- rts breadcrumb area -->

    <div class="rts-bread-crumb-area bg_image bg-breadcrumb">

        <div class="container ptb--65">

            <div class="row">

                <div class="col-lg-12">

                    <div class="con-tent-main">

                        <div class="wrapper">

                            <span class="bg-text-stok">Contact Us</span>

                            <div class="title skew-up">

                                <a href="#">Contact Us</a>

                            </div>

                            <div class="slug skew-up">

                                <a href="#index.html">HOME /</a>

                                <a class="active" href="#index.html">CONTACT</a>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- rts breadcrumb area end -->

    <!-- header style two End -->









    <!-- rts contact form area start  -->

    <div class="rts-contact-wrapper-form-area rts-section-gapBottom">

        <div class="container">

            <div class="row g-24">

                <div class="col-lg-7 col-md-12 col-sm-12 col-12">

                    <div class="form--area">

                        <div class="title-area-left">

                            <p class="pre">

                                <span>Feel Free</span> To COntact Us

                            </p>

                            <h2 class="title">

                                Get in Touch

                            </h2>

                        </div>

                        <div id="form-messages"></div>

                        <form id="contact-form" action="<?= base_url('/sendmail'); ?>" method="post" class="contact-page-form mt--30" autocomplete="off">

                            <div class="name-email-wraper">

                                <input id="name" name="name" type="text" placeholder="Your Name" required>

                                <input id="email" name="email" type="email" placeholder="Email Address" required>

                            </div>

                            <input id="subject" type="text" name="subject" placeholder="Select Subject">

                            <textarea id="message" name="message" placeholder="Type Your Message" required></textarea>

                            <button type="submit" class="rts-btn btn-primary">Send Message</button>

                        </form>

                    </div>

                </div>

                <div class="col-lg-5 col-md-12 col-sm-12 col-12">

                    <div class="map-area-wrapper">

                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1892.3746566519344!2d73.83467593857581!3d18.44968789565754!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2953224a9ac11%3A0x4aae6f87fb362c4b!2sVEDANT%20LIGHTS%20INDIA%20PRIVATE%20LIMITED!5e0!3m2!1sen!2sin!4v1687853706887!5m2!1sen!2sin" width="600" height="690" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- rts contact form area end  -->

<?= $this->include('Home/webfooter'); ?>