<?= $this->include('Home/webheader'); ?>
  <!-- rts breadcrumb area -->
    <div class="rts-bread-crumb-area bg_image bg-breadcrumb">
        <div class="container ptb--65">
            <div class="row">
                <div class="col-lg-12">
                    <div class="con-tent-main">
                        <div class="wrapper">
                            <span class="bg-text-stok">Brand</span>
                            <div class="title skew-up">
                                <a href="#"><?php if(!empty($brandName)) echo $brandName; ?></a>
                            </div>
                            <div class="slug skew-up">
                                <a href="#">HOME /</a>
                                <a class="active" href="#">Brand</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- rts breadcrumb area end -->

<!-- rts service area start -->
<div class="rts-service-area rts-section-gap-category">
    <div class="container">
        <div class="row g-24 mt--30">
              <?php 
                if(!empty($catDetails)) { 
                    foreach($catDetails as $vals) { ?>
           <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                <!-- single service -->
               <a href='<?php echo base_url(); ?>categoryDetails/<?php echo $brandId; ?>/<?php echo $brandName; ?>/<?php echo $vals["cat_id"]; ?>'>  <div class="rts-single-service-solar-energy-category">
                   <h6 class="title"><?php echo $vals["caterogyName"]; ?></h6>
                </div></a>
                <!-- single service end -->
            </div>
        <?php } } ?>
        </div>
    </div>
</div>

<div class="shopping-area-start rts-section-gap">
        <div class="container">
            <div class="row g-24 mt--0">
               <?php 
                if(!empty($proDetails)) { 
                    foreach($proDetails as $valss) { ?>  
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb--30">
                    <!-- single shoppign nproduct end -->
                    <div class="single-shopping-product">
                        <a href="<?php echo base_url(); ?>productDetails/<?php echo $valss['pro_id']; ?>" class="thumbnail">
                            <img src='<?php echo base_url(); ?>uploads/Product/<?php echo $valss["pro_img"]; ?>' alt="No Product Found">
                            
                        </a>
                        <div class="inner-content">
                            <a href="<?php echo base_url(); ?>productDetails/<?php echo $valss['pro_id']; ?>">
                                <h6 class="title"><?php echo $valss["pro_name"]; ?></h6>
                            </a>
                            <a href="https://www.vedantlights.com/contactus" class="rts-btn btn-primary">Get Quote</a>
                        </div>
                    </div>
                    <!-- single shoppign nproduct end -->
                </div>
            <?php } } ?>
                
            </div>
           
        </div>
    </div>

<!-- rts service area end -->
<?= $this->include('Home/webfooter'); ?>