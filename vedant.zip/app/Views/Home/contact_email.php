Hello Admin

    Name : <?php echo $name;?>
    Email : <?php echo $email;?>
    Subject : <?php echo $subject;?>
    Message : <?php echo $message;?>
