<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>web_assets/images/fav.png">
    <title>Vedant Lights</title>

    <!-- fontawesome css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/plugins/fontawesome-6.css">
    <!-- fontawesome css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/plugins/unicons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/plugins/metismenu.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/vendor/animate.css">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/vendor/bootstrap.min.css">
    <!-- Custom css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_assets/css/style.css">
    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
      <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-JQXXEJD13X">
    </script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-JQXXEJD13X');
    </script>
</head>

<body class="solar-energy-home">

        <!-- header man start -->
        <div class="header-main-h2  header--sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="main-haeder-wrapper-h2">
                            <a href="<?php echo base_url(); ?>" class="logo-area">
                                <img src="<?php echo base_url(); ?>web_assets/images/logo/logo.png" alt="logo">
                            </a>

                            <!-- navigation area start -->
                            <div class="header-nav main-nav-one" >
                                <nav>
                                    <ul>
                                        <li>
                                            <a href="<?php echo base_url(); ?>">HOME</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo base_url(); ?>aboutus"  style="font-weight: bold;">ABOUT US</a>
                                        </li>
                                        <li class="has-dropdown">
                                            <a class="nav-link" href="#">BRAND</a>
                                            <ul class="submenu">
                                                <?php 
                                                if (!empty($brandDetails)) { 
                                                    $columnCount = 5;
                                                    $currentColumn = 1;
                                        
                                                    foreach ($brandDetails as $val) {
                                                        // Check if it's the start of a new column
                                                        if ($currentColumn == 1) {
                                                            echo '<div class="column">';
                                                        }
                                                        ?>
                                                        <li><a class="mobile-menu-link" href="<?php echo base_url(); ?>brandDetails/<?php echo $val["brand_id"]; ?>/<?php echo $val["brand_name"]; ?>"><?php echo $val["brand_name"]; ?></a></li>
                                                        <?php
                                                        // Check if it's the end of a column or the last item
                                                        if ($currentColumn == $columnCount || $val === end($brandDetails)) {
                                                            echo '</div>';
                                                            // Reset column count for the next set of values
                                                            $currentColumn = 1;
                                                        } else {
                                                            $currentColumn++;
                                                        }
                                                    }
                                                }
                                                ?>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="nav-link" href="<?php echo base_url(); ?>contactus">CONTACT</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="actions-area">
                                <div class="menu-btn" id="menu-btn">
                                    <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect y="14" width="20" height="2" fill="#4AAB3D" />
                                        <rect y="7" width="20" height="2" fill="#4AAB3D" />
                                        <rect width="20" height="2" fill="#4AAB3D" />
                                    </svg>
                                </div>
                                <a href="https://api.whatsapp.com/send/?phone=%2B919860638920&text&type=phone_number&app_absent=0" class="rts-btn btn-primary">Contact Us</a>
                            </div>
                            
                            <style>
                                .rts-btn {
                                    display: inline-block;
                                    padding: 10px 20px;
                                    background-color: #4CAF50;
                                    color: #fff;
                                    text-decoration: none;
                                    border-radius: 5px;
                                    cursor: pointer;
                                }
                            
                                /* Popup Styles */
                                .overlay {
                                    display: none;
                                    position: fixed;
                                    top: 0;
                                    left: 0;
                                    width: 100%;
                                    height: 100%;
                                    justify-content: center;
                                    align-items: center;
                                }
                            
                                .popup {
                                    display: none;
                                    background: #fff;
                                    padding: 20px;
                                    border-radius: 5px;
                                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
                                    text-align: center;
                                    display: inline-block; /* or display: block; */
                                    height: auto; /* Change height to auto */
                                    width: 100%;
                                    max-width: 700px; /* Limit maximum width */
                                }
                            
                                .download-item {
                                    display: flex;
                                    align-items: center;
                                    margin-bottom: 10px; /* Adjust margin */
                                }
                            
                                .download-item h6 {
                                    margin: 0;
                                    flex: 1; /* Allow text to grow */
                                }
                            
                                .download-btn {
                                    padding: 10px 20px;
                                    background-color: #4CAF50;
                                    color: #fff;
                                    text-decoration: none;
                                    border-radius: 5px;
                                    cursor: pointer;
                                    margin-left: 10px; /* Adjust margin */
                                }
                            
                                .download-btn span {
                                    margin-left: 10px;
                                }
                            
                                /* Responsive adjustments */
                                @media only screen and (max-width: 768px) {
                                    .popup {
                                        width: 90%; /* Adjust width for smaller screens */
                                    }
                                }
                            </style>

                            <!-- Brochure Widget -->
                            <div class="sidebar-widget brochure-widget">
                                <a href="#" class="rts-btn btn-primary" onclick="openPopup(event)">
                                    <span>Download Brochure</span>
                                </a>
                                <div class="overlay" id="overlay" onclick="closePopup()">
                                    <!-- Popup Box - Row 1 -->
                                    <div class="popup" id="popup" onclick="event.stopPropagation();">
                                        <div style="display: flex; flex-direction: column; align-items: stretch;">
                                            <div class="download-item">
                                                <h6 style="width: 200px;">Company Profile</h6>
                                                <a href="web_assets/images/company_profile.pdf" class="download-btn" download>
                                                    <span>Download</span>
                                                </a>
                                            </div>
                                            <div class="download-item">
                                                <h6 style="width: 200px;">Brochure - Lights Product</h6>
                                                <a href="web_assets/images/lights_product.pdf" class="download-btn" download>
                                                    <span>Download</span>
                                                </a>
                                            </div>
                                            <div class="download-item">
                                                <h6 style="width: 200px;">Brochure - Street Light Poles</h6>
                                                <a href="web_assets/images/street_light_poles.pdf" class="download-btn" download>
                                                    <span>Download</span>
                                                </a>
                                            </div>
                                            <div class="download-item">
                                                <h6 style="width: 200px;">Director Business Card</h6>
                                                <a href="web_assets/images/director_business_card.jpeg" class="download-btn" download>
                                                    <span>Download</span>
                                                </a>
                                            </div>
                                            <div class="download-item">
                                                <h6 style="width: 200px;">Director Business Card</h6>
                                                <a href="web_assets/images/director_business_card1.jpeg" class="download-btn" download>
                                                    <span>Download</span>
                                                </a>
                                            </div>
                                        </div>
                                        <button onclick="closePopup()">Close</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Script for Popup Functionality -->
                            <script>
                                function openPopup(event) {
                                    event.preventDefault();
                                    document.getElementById('overlay').style.display = 'flex';
                                    document.getElementById('popup').style.display = 'block';
                                }
                            
                                function closePopup() {
                                    document.getElementById('overlay').style.display = 'none';
                                    document.getElementById('popup').style.display = 'none';
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- header style two -->
        
        <div id="side-bar" class="side-bar header-two">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>
        <!-- inner menu area desktop start -->
        <div class="inner-main-wrapper-desk">
            <div class="thumbnail">
                <img src="<?php echo base_url(); ?>web_assets/images/banner/04.jpeg" alt="elevate">
            </div>
            <div class="inner-content">
                <h4 class="title"> Empowering global trade
                </h4>
                <p class="disc">
                    Our company seamlessly exports quality products to numerous countries, connecting markets and fostering international growth.
                </p>
                <br>
                <p> Sri Lanka, Qatar, Kuwait,Saudi Arabia, UAE, Oman, Australia, Singapore, Tanzania, Canada, Bangladesh, Nepal </p>
                <div class="footer">
                    <h4 class="title">Got a project in mind?</h4>
                    <a href="contactus.php" class="rts-btn btn-primary">Let's talk</a>
                </div>
            </div>
        </div>
        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
                <ul class="mainmenu metismenu" id="mobile-menu-active">
                    <li>
                        <a href="<?php echo base_url(); ?>">HOME</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>aboutus"  style="font-weight: bold;">ABOUT US</a>
                    </li>
                    <li class="has-dropdown">
                            <a class="" href="#">BRAND</a>
                                <ul class="submenu">
                                    <?php 
                                    if (!empty($brandDetails)) { 
                                        $columnCount = 5;
                                        $currentColumn = 1;
                                        
                                            foreach ($brandDetails as $val) {
                                            // Check if it's the start of a new column
                                                if ($currentColumn == 1) {
                                                    echo '<div class="main">';
                                                    }
                                                ?>
                                                    <li><a class="mobile-menu-link" href="<?php echo base_url(); ?>brandDetails/<?php echo $val["brand_id"]; ?>/<?php echo $val["brand_name"]; ?>"><?php echo $val["brand_name"]; ?></a></li>
                                                    <?php
                                                    // Check if it's the end of a column or the last item
                                                        if ($currentColumn == $columnCount || $val === end($brandDetails)) {
                                                            echo '</div>';
                                                            // Reset column count for the next set of values
                                                            $currentColumn = 1;
                                                        } else {
                                                            $currentColumn++;
                                                        }
                                                    }
                                                }
                                    ?>
                                </ul>
                            
                        
                    </li>
                    <li>
                    <a class="" href="<?php echo base_url(); ?>contactus">CONTACT</a>
                    </li>
                </ul>
            </nav>

            <div class="rts-social-style-one pl--20 mt--100">
                <ul>
                    <li>
                        <a href="https://www.facebook.com/vedantlightsindiaprivatelimited/">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://x.com/IndiaLight60091">
                            <i class="fa-brands fa-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.youtube.com/@vedantlights">
                            <i class="fa-brands fa-youtube"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.linkedin.com/in/sudhakar-poul/">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>                                    
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->
        </div>
        <!-- header man end -->
        
    </div>
    <!-- header style two End -->